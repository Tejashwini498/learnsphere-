import 'package:flutter/material.dart';

class Program {
  final String id;
  final String title;
  final String category;
  final String duration;
  final String deadline;
  final String level;
  final String description;
  final IconData icon;
  final Color color;

  const Program({
    required this.id,
    required this.title,
    required this.category,
    required this.duration,
    required this.deadline,
    required this.level,
    required this.description,
    required this.icon,
    required this.color,
  });
}

/// Placeholder/dummy data so navigation + UI can be demoed end-to-end
/// before the Week 3 API/data integration work begins.
final List<Program> dummyPrograms = [
  Program(
    id: 'p1',
    title: 'Software Engineering Externship',
    category: 'Technology',
    duration: '6 weeks',
    deadline: 'Jul 15, 2026',
    level: 'Intermediate',
    description:
        'Work in a simulated agile team to design, build, and ship a '
        'production-style feature. Includes mentor code reviews, sprint '
        'planning, and a final demo day presentation to industry mentors.',
    icon: Icons.code_rounded,
    color: const Color(0xFF0F4C81),
  ),
  Program(
    id: 'p2',
    title: 'Product Management Fundamentals',
    category: 'Business',
    duration: '4 weeks',
    deadline: 'Jul 20, 2026',
    level: 'Beginner',
    description:
        'Learn how product managers scope requirements, prioritize a '
        'roadmap, and work cross-functionally with design and engineering '
        'teams to launch a feature.',
    icon: Icons.dashboard_customize_rounded,
    color: const Color(0xFFFF7A00),
  ),
  Program(
    id: 'p3',
    title: 'UI/UX Design Sprint',
    category: 'Design',
    duration: '3 weeks',
    deadline: 'Jul 10, 2026',
    level: 'Beginner',
    description:
        'Translate wireframes into polished, user-tested interfaces. '
        'Covers design systems, accessibility, and portfolio-ready case '
        'studies.',
    icon: Icons.brush_rounded,
    color: const Color(0xFF2E9E5B),
  ),
  Program(
    id: 'p4',
    title: 'Data Analytics Bootcamp',
    category: 'Data',
    duration: '5 weeks',
    deadline: 'Jul 25, 2026',
    level: 'Intermediate',
    description:
        'Clean, model, and visualize real-world datasets. Finish with a '
        'capstone dashboard presented to a panel of data mentors.',
    icon: Icons.query_stats_rounded,
    color: const Color(0xFF7A4FE0),
  ),
  Program(
    id: 'p5',
    title: 'Digital Marketing Accelerator',
    category: 'Marketing',
    duration: '4 weeks',
    deadline: 'Aug 1, 2026',
    level: 'Beginner',
    description:
        'Plan and run a full campaign — audience research, content '
        'calendar, paid + organic channels, and performance reporting.',
    icon: Icons.campaign_rounded,
    color: const Color(0xFFE24949),
  ),
];
