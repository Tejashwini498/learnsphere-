# Excelerate Programs — Week 2 UI Prototype

A Flutter mobile UI prototype for the Excelerate Programs app, built for the
**Week 2 deliverable**: four interactive, navigable screens translated from
the Week 1 wireframes.

## Screens included

| Screen | File | Purpose |
|---|---|---|
| Login | `lib/screens/login_screen.dart` | Email/password form with validation, "Continue as Guest" shortcut |
| Home | `lib/screens/home_screen.dart` | Welcome banner, quick stats, featured programs |
| Program Listing | `lib/screens/program_listing_screen.dart` | Searchable, filterable list of programs |
| Program Details | `lib/screens/program_details_screen.dart` | Full program info + "Apply Now" action |

## Navigation flow

```
LoginScreen
   │ (Log In / Continue as Guest)
   ▼
HomeScreen ──(Browse Programs / bottom nav)──► ProgramListingScreen
   │ (tap a featured program)                        │ (tap any program card)
   ▼                                                  ▼
ProgramDetailsScreen ◄─────────────────────────────────
```

All navigation uses `Navigator.push` / `pushReplacement`, so the back button
and gestures work naturally on both Android and iOS.

## Branding

Brand tokens (colors, button/card/input styles) live in one place —
`lib/theme/app_theme.dart` — so the app stays visually consistent as more
screens are added in later weeks. Colors used are placeholders (deep blue
`#0F4C81` + accent orange `#FF7A00`); swap in the official Excelerate brand
kit hex codes and logo once available.

## Getting started

1. **Install Flutter** (if you haven't already): https://docs.flutter.dev/get-started/install
2. From the project root:
   ```bash
   flutter pub get
   flutter run
   ```
3. To run on a specific device:
   ```bash
   flutter devices        # list available devices/emulators
   flutter run -d chrome  # e.g. run in a browser for a quick check
   ```
4. To build a release APK for submission/demo purposes:
   ```bash
   flutter build apk --release
   ```

> This prototype uses in-memory dummy data (`lib/models/program.dart`) —
> no backend or API calls yet. That integration is planned for Week 3.

## Screenshots

> Run the app on an emulator/device or `flutter run -d chrome`, then replace
> these placeholders with real captures before submitting.

| Login | Home | Program Listing | Program Details |
|---|---|---|---|
| `screenshots/login.png` | `screenshots/home.png` | `screenshots/listing.png` | `screenshots/details.png` |

To capture screenshots quickly:
- **Emulator**: use the emulator's built-in camera/screenshot button.
- **Physical device**: `flutter screenshot` while `flutter run` is active.
- **Chrome**: browser dev tools → device toolbar → screenshot.

Save the files into the `screenshots/` folder using the names above so the
table renders correctly on GitHub.

## Suggested commit history

Meaningful, incremental commits reviewers can follow:

```
feat: scaffold Flutter project structure
feat: add shared app theme and brand tokens
feat: build Login screen with form validation
feat: build Home screen with featured programs
feat: build Program Listing screen with search + filters
feat: build Program Details screen with apply flow
feat: wire up navigation between all four screens
docs: add README with setup instructions and screenshots
```

## Demo video (optional)

A 2–3 minute screen recording should show, in order:
1. Login screen → validation error → successful login
2. Home screen → tap "Browse Programs"
3. Program Listing → search/filter → tap a program card
4. Program Details → scroll → tap "Apply Now"

Briefly narrate the design choices (branding, layout, card-based listing)
and how they map back to the Week 1 wireframes.

## Learning outcomes covered

- Translated Week 1 wireframes into functional Flutter widgets
- Implemented multi-screen navigation with `Navigator`
- Applied a centralized theme for consistent Excelerate branding
- Built a working, interactive prototype ready for Week 3 data integration
