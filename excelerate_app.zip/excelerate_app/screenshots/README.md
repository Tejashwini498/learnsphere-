Drop your captured screenshots here:

- login.png
- home.png
- listing.png
- details.png

See the main README's "Screenshots" section for capture instructions.
