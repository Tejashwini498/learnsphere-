# Program App (Flutter)

A Flutter app for browsing training/education programs, viewing program details, and submitting feedback or registration requests.

## Features

- **Program Listing** — scrollable list of programs pulled from JSON data, with pull-to-refresh.
- **Program Details** — full description, instructor, seats available, price, and a call-to-action to register.
- **Feedback / Registration Form** — validated form for name, email, password, and message.
- **Loading & error states** — spinners while data loads, friendly error screens with a Retry button if something fails.

## Getting Started

```bash
flutter pub get
flutter run
```

## Project Structure

```
lib/
  main.dart
  models/
    program.dart              # Program data model + JSON parsing
  services/
    program_service.dart      # Loads program data (JSON now, real API later)
  screens/
    program_list_screen.dart  # Program Listing screen
    program_detail_screen.dart# Program Details screen
    feedback_form_screen.dart # Feedback / Registration form
  widgets/
    state_views.dart          # Shared Loading / Error / Empty widgets
assets/
  data/
    programs.json             # Mock API data
```

## What Changed This Week (Week 3)

- Replaced hardcoded text on the **Program Listing** and **Program Details** screens with real data loaded from `assets/data/programs.json` via `ProgramService`.
- Added a **Feedback / Registration form** (`feedback_form_screen.dart`) reachable from both the app bar and each Program Details screen.
- Added **form validation**: required name, valid email format, password with a minimum length and letter+number requirement, and a minimum-length message field.
- Added **loading indicators** (`CircularProgressIndicator`) while data is fetched, and **error handling** with a Retry button if loading fails.
- Added **pull-to-refresh** on the Program Listing screen.
- Structured `ProgramService` so it can be pointed at a real REST API later by swapping the JSON-loading code for an `http.get()` call — no changes needed anywhere else in the app.

See `CHANGELOG_WEEK3.md` for the full write-up.

## Next Steps

- Swap `ProgramService.fetchPrograms()` to call a real hosted API endpoint.
- Persist form submissions (e.g., to Firebase or a backend database).
- Add unit tests for `Program.fromJson` and the form validators.
