import 'package:flutter/material.dart';

import 'screens/program_list_screen.dart';

void main() {
  runApp(const ProgramApp());
}

class ProgramApp extends StatelessWidget {
  const ProgramApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Program App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.blue,
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const ProgramListScreen(),
    );
  }
}
