class Program {
  final String id;
  final String title;
  final String category;
  final String duration;
  final String level;
  final double rating;
  final String imageUrl;
  final String shortDescription;
  final String fullDescription;
  final String instructor;
  final int seatsAvailable;
  final double price;

  Program({
    required this.id,
    required this.title,
    required this.category,
    required this.duration,
    required this.level,
    required this.rating,
    required this.imageUrl,
    required this.shortDescription,
    required this.fullDescription,
    required this.instructor,
    required this.seatsAvailable,
    required this.price,
  });

  /// Builds a Program from a JSON map.
  /// Uses defensive parsing so a single malformed record
  /// doesn't crash the whole list.
  factory Program.fromJson(Map<String, dynamic> json) {
    return Program(
      id: json['id']?.toString() ?? '',
      title: json['title'] as String? ?? 'Untitled Program',
      category: json['category'] as String? ?? 'General',
      duration: json['duration'] as String? ?? 'N/A',
      level: json['level'] as String? ?? 'All Levels',
      rating: (json['rating'] as num?)?.toDouble() ?? 0.0,
      imageUrl: json['imageUrl'] as String? ?? '',
      shortDescription: json['shortDescription'] as String? ?? '',
      fullDescription: json['fullDescription'] as String? ?? '',
      instructor: json['instructor'] as String? ?? 'TBA',
      seatsAvailable: (json['seatsAvailable'] as num?)?.toInt() ?? 0,
      price: (json['price'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
