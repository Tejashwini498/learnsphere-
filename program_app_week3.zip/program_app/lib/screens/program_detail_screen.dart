import 'package:flutter/material.dart';

import '../models/program.dart';
import '../services/program_service.dart';
import '../widgets/state_views.dart';
import 'feedback_form_screen.dart';

class ProgramDetailScreen extends StatefulWidget {
  final String programId;
  const ProgramDetailScreen({super.key, required this.programId});

  @override
  State<ProgramDetailScreen> createState() => _ProgramDetailScreenState();
}

class _ProgramDetailScreenState extends State<ProgramDetailScreen> {
  final ProgramService _service = ProgramService();
  late Future<Program> _programFuture;

  @override
  void initState() {
    super.initState();
    _loadProgram();
  }

  void _loadProgram() {
    setState(() {
      _programFuture = _service.fetchProgramById(widget.programId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Program Details')),
      body: FutureBuilder<Program>(
        future: _programFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const LoadingView(message: 'Loading program details...');
          }

          if (snapshot.hasError) {
            return ErrorView(
              message: snapshot.error.toString().replaceFirst('ProgramLoadException: ', ''),
              onRetry: _loadProgram,
            );
          }

          final program = snapshot.data!;
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.network(
                  program.imageUrl,
                  width: double.infinity,
                  height: 220,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 220,
                    color: Colors.grey[300],
                    child: const Icon(Icons.school_outlined, size: 48),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(program.title,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Icon(Icons.star, color: Colors.amber[700], size: 18),
                          const SizedBox(width: 4),
                          Text('${program.rating}'),
                          const SizedBox(width: 16),
                          const Icon(Icons.person_outline, size: 18),
                          const SizedBox(width: 4),
                          Text(program.instructor),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          _InfoPill(icon: Icons.category_outlined, label: program.category),
                          _InfoPill(icon: Icons.schedule, label: program.duration),
                          _InfoPill(icon: Icons.bar_chart, label: program.level),
                          _InfoPill(
                              icon: Icons.event_seat_outlined,
                              label: '${program.seatsAvailable} seats left'),
                        ],
                      ),
                      const SizedBox(height: 20),
                      const Text('About this program',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Text(program.fullDescription, style: const TextStyle(height: 1.5)),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '\$${program.price.toStringAsFixed(2)}',
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          ElevatedButton.icon(
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) =>
                                      FeedbackFormScreen(prefilledProgramTitle: program.title),
                                ),
                              );
                            },
                            icon: const Icon(Icons.how_to_reg_outlined),
                            label: const Text('Register / Feedback'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _InfoPill extends StatelessWidget {
  final IconData icon;
  final String label;
  const _InfoPill({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: Colors.grey[700]),
          const SizedBox(width: 5),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[800])),
        ],
      ),
    );
  }
}
