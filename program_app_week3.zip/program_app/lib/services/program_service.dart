import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
// import 'package:http/http.dart' as http; // <- uncomment to switch to a real API

import '../models/program.dart';

/// Custom exception so the UI can show a friendly error message
/// instead of a raw stack trace.
class ProgramLoadException implements Exception {
  final String message;
  ProgramLoadException(this.message);

  @override
  String toString() => message;
}

class ProgramService {
  /// Local mock "API": reads assets/data/programs.json.
  ///
  /// To connect this to a REAL API later, replace the body of this method
  /// with something like:
  ///
  /// final response = await http
  ///     .get(Uri.parse('https://your-api.com/programs'))
  ///     .timeout(const Duration(seconds: 10));
  /// if (response.statusCode != 200) {
  ///   throw ProgramLoadException('Server error: ${response.statusCode}');
  /// }
  /// final data = jsonDecode(response.body);
  ///
  /// Everything else (parsing into Program objects, error handling in the
  /// UI) stays exactly the same, because both paths return a
  /// Future<List<Program>> and throw ProgramLoadException on failure.
  Future<List<Program>> fetchPrograms() async {
    try {
      // Simulate network latency so the loading indicator is visible.
      await Future.delayed(const Duration(milliseconds: 900));

      final String jsonString =
          await rootBundle.loadString('assets/data/programs.json');
      final Map<String, dynamic> data = jsonDecode(jsonString);

      final List<dynamic> rawList = data['programs'] as List<dynamic>? ?? [];

      if (rawList.isEmpty) {
        throw ProgramLoadException('No programs were found.');
      }

      return rawList
          .map((item) => Program.fromJson(item as Map<String, dynamic>))
          .toList();
    } on FormatException {
      throw ProgramLoadException('The program data is corrupted or invalid.');
    } catch (e) {
      if (e is ProgramLoadException) rethrow;
      throw ProgramLoadException('Could not load programs. Please try again.');
    }
  }

  /// Fetch a single program by id — used by the Details screen so it can
  /// re-fetch fresh data (mirrors how a real GET /programs/{id} would work).
  Future<Program> fetchProgramById(String id) async {
    final programs = await fetchPrograms();
    return programs.firstWhere(
      (p) => p.id == id,
      orElse: () => throw ProgramLoadException('Program not found.'),
    );
  }

  /// Simulates submitting the feedback/registration form to an API.
  /// Returns normally on "success"; throws on simulated failure.
  Future<void> submitFeedback({
    required String name,
    required String email,
    required String password,
    required String message,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    // In a real API integration this would be:
    // final response = await http.post(
    //   Uri.parse('https://your-api.com/feedback'),
    //   headers: {'Content-Type': 'application/json'},
    //   body: jsonEncode({
    //     'name': name,
    //     'email': email,
    //     'password': password,
    //     'message': message,
    //   }),
    // );
    // if (response.statusCode != 200 && response.statusCode != 201) {
    //   throw ProgramLoadException('Submission failed: ${response.statusCode}');
    // }

    // Mock success — no exception thrown means the UI treats it as OK.
    return;
  }
}
