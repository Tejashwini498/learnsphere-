# Week 3 Changelog & Documentation

**Project:** Program App (Flutter)
**Week:** 3 — API-Connected Functional App
**Date:** July 2026

---

## 1. Screens Now Fetching Data from JSON

| Screen | Before | After |
|---|---|---|
| **Program Listing** (`program_list_screen.dart`) | Hardcoded list of program names/text in the widget tree | Fetches all programs from `assets/data/programs.json` through `ProgramService.fetchPrograms()` and renders them in a `ListView.separated` |
| **Program Details** (`program_detail_screen.dart`) | Hardcoded title/description/instructor text | Fetches a single program by ID through `ProgramService.fetchProgramById(id)` and renders title, description, instructor, category, duration, level, seats available, and price dynamically |

**How it works:**
`ProgramService` currently reads `assets/data/programs.json` (acting as a mock API) using `rootBundle.loadString()`, decodes it with `jsonDecode`, and maps each record into a `Program` model object (`Program.fromJson`). A small artificial delay (900ms) is added so the loading state is visible, simulating real network latency.

The service is intentionally structured so it can be pointed at a **real REST API** later by replacing the JSON-loading code inside `fetchPrograms()` with an `http.get()` call — the rest of the app (UI, error handling, models) doesn't need to change, since both paths return a `Future<List<Program>>`.

---

## 2. Form Added: Feedback / Registration Form

**File:** `lib/screens/feedback_form_screen.dart`

**Purpose:** Lets a user register interest in a program or leave general feedback. Accessible from:
- The app bar icon on the Program Listing screen (general feedback).
- The "Register / Feedback" button on each Program Details screen (pre-fills a message referencing that program).

**Fields & Validation:**

| Field | Validation Rule |
|---|---|
| Full Name | Required, minimum 2 characters |
| Email | Required, must match a valid email pattern (`name@domain.tld`) |
| Password | Required, minimum 6 characters, must contain at least one letter **and** one number |
| Message / Feedback | Required, minimum 10 characters |

Validation uses Flutter's built-in `Form` + `TextFormField` + `GlobalKey<FormState>` pattern, with `AutovalidateMode.onUserInteraction` so errors appear live as the user types after their first interaction with a field. Submission is blocked until `_formKey.currentState.validate()` returns true.

On submit, the form calls `ProgramService.submitFeedback()` (currently a mocked async call simulating a POST request) and shows:
- A green success `SnackBar` and clears the form on success.
- A red error `SnackBar` with the failure reason if the (simulated) submission fails.

---

## 3. Loading & Error Handling

Implemented in `lib/widgets/state_views.dart` and used across both data-driven screens:

- **`LoadingView`** — shown while `FutureBuilder`'s `ConnectionState` is `waiting`. Displays a `CircularProgressIndicator` with a status message.
- **`ErrorView`** — shown if the future throws. Displays the error message and a **Retry** button that re-triggers the fetch.
- **`EmptyView`** — shown if the fetch succeeds but returns zero programs (defensive UX for an empty dataset).
- **Pull-to-refresh** on the Program Listing screen via `RefreshIndicator`.
- **Image loading/error handling** — `Image.network` calls include `loadingBuilder` (shows a small spinner while thumbnails load) and `errorBuilder` (shows a placeholder icon if an image fails to load).
- **Defensive JSON parsing** — `Program.fromJson` uses null-coalescing fallbacks so one malformed record won't crash the entire list, and a custom `ProgramLoadException` is thrown with a human-readable message on failure (corrupted data, empty list, etc.) instead of a raw exception.

---

## 4. Summary of Files Changed/Added This Week

- `lib/models/program.dart` — new data model
- `lib/services/program_service.dart` — new mock-API service layer
- `lib/screens/program_list_screen.dart` — connected to JSON data, loading/error states, pull-to-refresh
- `lib/screens/program_detail_screen.dart` — connected to JSON data, loading/error states
- `lib/screens/feedback_form_screen.dart` — new validated form
- `lib/widgets/state_views.dart` — new shared loading/error/empty widgets
- `assets/data/programs.json` — new mock dataset (5 sample programs)
- `pubspec.yaml` — added `http` dependency and registered the JSON asset
- `README.md` — updated with Week 3 notes

---

## 5. Suggested Commit Messages (for GitHub push)

```
Connected Program Listing screen to JSON data
Connected Program Details screen to JSON data
Added feedback/registration form with validation
Added loading and error handling with retry
Updated README with Week 3 changes
```
