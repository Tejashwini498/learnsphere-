import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:learnsphere/main.dart';

void main() {
  testWidgets('App boots and shows splash content', (WidgetTester tester) async {
    await tester.pumpWidget(const LearnSphereApp());
    await tester.pump();

    expect(find.text('LearnSphere'), findsOneWidget);
  });

  testWidgets('Login screen renders email and password fields', (WidgetTester tester) async {
    await tester.pumpWidget(const LearnSphereApp());
    // Let the splash screen's delayed navigation complete.
    await tester.pumpAndSettle(const Duration(seconds: 2));

    expect(find.text('Welcome back'), findsOneWidget);
    expect(find.widgetWithText(ElevatedButton, 'Log In'), findsOneWidget);
  });
}
