/// App-wide constants: strings, spacing, and simple config values.
class AppConstants {
  AppConstants._();

  static const String appName = 'LearnSphere';
  static const String appTagline = 'Learn. Track. Achieve.';

  // Spacing
  static const double spaceXs = 4;
  static const double spaceSm = 8;
  static const double spaceMd = 16;
  static const double spaceLg = 24;
  static const double spaceXl = 32;

  // Radii
  static const double radiusSm = 8;
  static const double radiusMd = 14;
  static const double radiusLg = 20;

  // Categories shown on Home / Program Listing
  static const List<String> categories = [
    'Dev',
    'Data',
    'Design',
    'Cloud',
  ];

  static const List<String> levels = ['Beginner', 'Intermediate', 'Advanced'];
}
