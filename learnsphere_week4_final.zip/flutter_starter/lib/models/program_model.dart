class CurriculumModule {
  final String title;
  final String duration;

  const CurriculumModule({required this.title, required this.duration});
}

class Program {
  final String id;
  final String title;
  final String category; // Dev, Data, Design, Cloud
  final String level; // Beginner, Intermediate, Advanced
  final String duration; // e.g. "8 weeks"
  final double rating;
  final int reviewCount;
  final String instructor;
  final String description;
  final List<CurriculumModule> curriculum;

  /// 0.0 - 1.0 progress for the current learner, if enrolled.
  final double progress;
  final bool enrolled;

  const Program({
    required this.id,
    required this.title,
    required this.category,
    required this.level,
    required this.duration,
    required this.rating,
    required this.reviewCount,
    required this.instructor,
    required this.description,
    required this.curriculum,
    this.progress = 0.0,
    this.enrolled = false,
  });

  Program copyWith({double? progress, bool? enrolled}) {
    return Program(
      id: id,
      title: title,
      category: category,
      level: level,
      duration: duration,
      rating: rating,
      reviewCount: reviewCount,
      instructor: instructor,
      description: description,
      curriculum: curriculum,
      progress: progress ?? this.progress,
      enrolled: enrolled ?? this.enrolled,
    );
  }
}
