import 'package:flutter/foundation.dart';
import '../models/program_model.dart';

class FeedbackEntry {
  final String programTitle;
  final int rating;
  final String comment;
  final DateTime submittedAt;

  FeedbackEntry({
    required this.programTitle,
    required this.rating,
    required this.comment,
    required this.submittedAt,
  });
}

/// Simulates a backend for programs, enrollments, and feedback submissions.
/// Swap the in-memory list for real `http` calls when a backend is ready —
/// the public method signatures are designed to stay the same.
class ProgramService extends ChangeNotifier {
  final List<Program> _programs = _seedPrograms();
  final List<FeedbackEntry> _feedback = [];

  List<Program> get programs => List.unmodifiable(_programs);
  List<FeedbackEntry> get feedback => List.unmodifiable(_feedback);

  List<Program> get continueLearning =>
      _programs.where((p) => p.enrolled && p.progress < 1.0).toList();

  Future<List<Program>> fetchPrograms({String? category, String? query}) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _programs.where((p) {
      final matchesCategory =
          category == null || category == 'All' || p.category == category;
      final matchesQuery = query == null ||
          query.isEmpty ||
          p.title.toLowerCase().contains(query.toLowerCase());
      return matchesCategory && matchesQuery;
    }).toList();
  }

  Program getById(String id) => _programs.firstWhere((p) => p.id == id);

  Future<void> enroll(String programId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final index = _programs.indexWhere((p) => p.id == programId);
    if (index == -1) return;
    _programs[index] =
        _programs[index].copyWith(enrolled: true, progress: 0.05);
    notifyListeners();
  }

  Future<void> submitFeedback({
    required String programTitle,
    required int rating,
    required String comment,
  }) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _feedback.add(FeedbackEntry(
      programTitle: programTitle,
      rating: rating,
      comment: comment,
      submittedAt: DateTime.now(),
    ));
    notifyListeners();
  }

  static List<Program> _seedPrograms() {
    return [
      Program(
        id: 'p1',
        title: 'Python for Data Science',
        category: 'Data',
        level: 'Beginner',
        duration: '8 weeks',
        rating: 4.3,
        reviewCount: 120,
        instructor: 'LearnSphere Academy',
        description:
            'A hands-on introduction to Python, Pandas, and NumPy for '
            'real-world data analysis, building toward your first '
            'end-to-end data project.',
        curriculum: const [
          CurriculumModule(title: 'Python Fundamentals', duration: '1 wk'),
          CurriculumModule(title: 'Data Wrangling with Pandas', duration: '2 wk'),
          CurriculumModule(title: 'Visualization with Matplotlib', duration: '2 wk'),
          CurriculumModule(title: 'Capstone Project', duration: '3 wk'),
        ],
        enrolled: true,
        progress: 0.45,
      ),
      Program(
        id: 'p2',
        title: 'Flutter App Development',
        category: 'Dev',
        level: 'Beginner',
        duration: '6 weeks',
        rating: 4.6,
        reviewCount: 98,
        instructor: 'LearnSphere Academy',
        description:
            'Learn to design and build cross-platform mobile apps with '
            'Flutter and Dart, from widgets to state management.',
        curriculum: const [
          CurriculumModule(title: 'Dart Basics', duration: '1 wk'),
          CurriculumModule(title: 'Widgets & Layouts', duration: '2 wk'),
          CurriculumModule(title: 'Navigation & State', duration: '2 wk'),
          CurriculumModule(title: 'Publishing Your App', duration: '1 wk'),
        ],
      ),
      Program(
        id: 'p3',
        title: 'UI/UX Design Foundations',
        category: 'Design',
        level: 'Beginner',
        duration: '5 weeks',
        rating: 4.4,
        reviewCount: 76,
        instructor: 'LearnSphere Academy',
        description:
            'Master the fundamentals of user-centered design, wireframing, '
            'and prototyping tools used by professional product teams.',
        curriculum: const [
          CurriculumModule(title: 'Design Thinking', duration: '1 wk'),
          CurriculumModule(title: 'Wireframing', duration: '1 wk'),
          CurriculumModule(title: 'Prototyping in Figma', duration: '2 wk'),
          CurriculumModule(title: 'Usability Testing', duration: '1 wk'),
        ],
      ),
      Program(
        id: 'p4',
        title: 'AWS Cloud Practitioner',
        category: 'Cloud',
        level: 'Intermediate',
        duration: '7 weeks',
        rating: 4.2,
        reviewCount: 154,
        instructor: 'LearnSphere Academy',
        description:
            'Build a solid foundation in AWS core services, cloud '
            'architecture, and security best practices.',
        curriculum: const [
          CurriculumModule(title: 'Cloud Concepts', duration: '1 wk'),
          CurriculumModule(title: 'Core AWS Services', duration: '3 wk'),
          CurriculumModule(title: 'Security & Compliance', duration: '2 wk'),
          CurriculumModule(title: 'Mock Exam & Review', duration: '1 wk'),
        ],
      ),
      Program(
        id: 'p5',
        title: 'Advanced SQL for Analysts',
        category: 'Data',
        level: 'Intermediate',
        duration: '4 weeks',
        rating: 4.5,
        reviewCount: 61,
        instructor: 'LearnSphere Academy',
        description:
            'Go beyond SELECT statements: window functions, query '
            'optimization, and real analytics case studies.',
        curriculum: const [
          CurriculumModule(title: 'Joins & Subqueries', duration: '1 wk'),
          CurriculumModule(title: 'Window Functions', duration: '1 wk'),
          CurriculumModule(title: 'Query Optimization', duration: '1 wk'),
          CurriculumModule(title: 'Analytics Case Studies', duration: '1 wk'),
        ],
      ),
      Program(
        id: 'p6',
        title: 'React Essentials',
        category: 'Dev',
        level: 'Intermediate',
        duration: '6 weeks',
        rating: 4.1,
        reviewCount: 88,
        instructor: 'LearnSphere Academy',
        description:
            'Build interactive single-page applications with React, hooks, '
            'and component-driven architecture.',
        curriculum: const [
          CurriculumModule(title: 'JSX & Components', duration: '1 wk'),
          CurriculumModule(title: 'Hooks & State', duration: '2 wk'),
          CurriculumModule(title: 'Routing & APIs', duration: '2 wk'),
          CurriculumModule(title: 'Final Project', duration: '1 wk'),
        ],
      ),
    ];
  }
}
