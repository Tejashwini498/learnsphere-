import 'package:flutter/foundation.dart';
import '../models/user_model.dart';

/// Simulates an authentication API. In a real backend integration this
/// would call Firebase Auth / a REST endpoint instead of using a delay.
class AuthService extends ChangeNotifier {
  AppUser? _currentUser;

  AppUser? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;

  Future<AppUser> login({required String email, required String password}) async {
    await Future.delayed(const Duration(milliseconds: 700));

    if (email.trim().isEmpty || password.trim().isEmpty) {
      throw AuthException('Email and password are required.');
    }
    if (!email.contains('@')) {
      throw AuthException('Enter a valid email address.');
    }
    if (password.length < 4) {
      throw AuthException('Password must be at least 4 characters.');
    }

    final isAdmin = email.toLowerCase().startsWith('admin');
    _currentUser = AppUser(
      id: 'u_${email.hashCode}',
      name: isAdmin ? 'Rahul (Admin)' : email.split('@').first,
      email: email,
      role: isAdmin ? UserRole.admin : UserRole.learner,
    );
    notifyListeners();
    return _currentUser!;
  }

  Future<AppUser> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    await Future.delayed(const Duration(milliseconds: 700));

    if (name.trim().isEmpty) throw AuthException('Name is required.');
    if (!email.contains('@')) throw AuthException('Enter a valid email address.');
    if (password.length < 4) {
      throw AuthException('Password must be at least 4 characters.');
    }

    _currentUser = AppUser(
      id: 'u_${email.hashCode}',
      name: name,
      email: email,
      role: UserRole.learner,
    );
    notifyListeners();
    return _currentUser!;
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}

class AuthException implements Exception {
  final String message;
  AuthException(this.message);
  @override
  String toString() => message;
}
