import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/program_service.dart';
import '../utils/constants.dart';
import '../utils/theme.dart';
import 'program_details_screen.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final service = context.watch<ProgramService>();
    final enrolled = service.programs.where((p) => p.enrolled).toList();

    return ListView(
      padding: const EdgeInsets.all(AppConstants.spaceLg),
      children: [
        const Text('My Progress', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text('${enrolled.length} program${enrolled.length == 1 ? '' : 's'} in progress',
            style: const TextStyle(color: AppColors.textSecondary)),
        const SizedBox(height: 20),
        if (enrolled.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 40),
            child: Center(
              child: Text('Enroll in a program to start tracking your progress here.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.textSecondary)),
            ),
          )
        else
          for (final program in enrolled)
            Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: InkWell(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => ProgramDetailsScreen(programId: program.id),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(program.title,
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                          ),
                          if (program.progress >= 1.0)
                            const Icon(Icons.workspace_premium_rounded,
                                color: Color(0xFFF59E0B), size: 20),
                        ],
                      ),
                      const SizedBox(height: 10),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(
                          value: program.progress,
                          minHeight: 8,
                          backgroundColor: AppColors.border,
                          valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        program.progress >= 1.0
                            ? 'Completed 🎉'
                            : '${(program.progress * 100).round()}% complete',
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                ),
              ),
            ),
      ],
    );
  }
}
