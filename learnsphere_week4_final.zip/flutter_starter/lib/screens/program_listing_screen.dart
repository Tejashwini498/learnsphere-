import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/program_model.dart';
import '../services/program_service.dart';
import '../utils/constants.dart';
import '../utils/theme.dart';
import 'program_details_screen.dart';

/// Shown both as the "Programs" bottom-nav tab (embedded: true, no AppBar)
/// and as a standalone pushed screen when opened from search or a category.
class ProgramListingScreen extends StatefulWidget {
  final bool embedded;
  final String? initialCategory;

  const ProgramListingScreen({super.key, this.embedded = false, this.initialCategory});

  @override
  State<ProgramListingScreen> createState() => _ProgramListingScreenState();
}

class _ProgramListingScreenState extends State<ProgramListingScreen> {
  final _searchController = TextEditingController();
  late String _selectedCategory;
  late Future<List<Program>> _future;

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.initialCategory ?? 'All';
    _future = context.read<ProgramService>().fetchPrograms();
  }

  void _refilter() {
    setState(() {
      _future = context.read<ProgramService>().fetchPrograms(
            category: _selectedCategory,
            query: _searchController.text,
          );
    });
  }

  @override
  Widget build(BuildContext context) {
    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(
              AppConstants.spaceLg, AppConstants.spaceLg, AppConstants.spaceLg, 0),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onSubmitted: (_) => _refilter(),
                  decoration: InputDecoration(
                    hintText: 'Search...',
                    prefixIcon: const Icon(Icons.search_rounded),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                onPressed: _refilter,
                icon: const Icon(Icons.filter_list_rounded),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 40,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: AppConstants.spaceLg),
            scrollDirection: Axis.horizontal,
            itemCount: AppConstants.categories.length + 1,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, i) {
              final label = i == 0 ? 'All' : AppConstants.categories[i - 1];
              final selected = _selectedCategory == label;
              return ChoiceChip(
                label: Text(label),
                selected: selected,
                onSelected: (_) {
                  _selectedCategory = label;
                  _refilter();
                },
                selectedColor: AppColors.primary,
                labelStyle: TextStyle(
                  color: selected ? Colors.white : AppColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: FutureBuilder<List<Program>>(
            future: _future,
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final results = snapshot.data!;
              if (results.isEmpty) {
                return const Center(child: Text('No programs match your search.'));
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(
                    AppConstants.spaceLg, 0, AppConstants.spaceLg, AppConstants.spaceLg),
                itemCount: results.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, i) {
                  final program = results[i];
                  return _ListingCard(program: program);
                },
              );
            },
          ),
        ),
      ],
    );

    if (widget.embedded) return content;

    return Scaffold(
      appBar: AppBar(title: const Text('Programs')),
      body: content,
    );
  }
}

class _ListingCard extends StatelessWidget {
  final Program program;
  const _ListingCard({required this.program});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ProgramDetailsScreen(programId: program.id)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: AppColors.secondary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.menu_book_rounded, color: AppColors.secondary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(program.title,
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    const SizedBox(height: 4),
                    Text('${program.level} • ${program.duration} • Certificate',
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.star_rounded, size: 15, color: Color(0xFFF59E0B)),
                        Text(' ${program.rating}  (${program.reviewCount} reviews)',
                            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      ],
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => ProgramDetailsScreen(programId: program.id)),
                ),
                child: const Text('View'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
