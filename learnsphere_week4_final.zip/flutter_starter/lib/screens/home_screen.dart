import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/program_model.dart';
import '../services/auth_service.dart';
import '../services/program_service.dart';
import '../utils/constants.dart';
import '../utils/theme.dart';
import '../widgets/program_card.dart';
import 'admin_dashboard_screen.dart';
import 'profile_screen.dart';
import 'program_details_screen.dart';
import 'program_listing_screen.dart';
import 'progress_screen.dart';

/// The main app shell shown after login: bottom-nav across Home, Programs,
/// Progress, and Profile. Admin accounts see the Admin Dashboard instead.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tabIndex = 0;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();

    if (auth.currentUser?.isAdmin == true) {
      return const AdminDashboardScreen();
    }

    final tabs = const [
      _HomeTab(),
      ProgramListingScreen(embedded: true),
      ProgressScreen(),
      ProfileScreen(),
    ];

    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _tabIndex, children: tabs)),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tabIndex,
        onTap: (i) => setState(() => _tabIndex = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.grid_view_rounded), label: 'Programs'),
          BottomNavigationBarItem(icon: Icon(Icons.trending_up_rounded), label: 'Progress'),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatefulWidget {
  const _HomeTab();

  @override
  State<_HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<_HomeTab> {
  late Future<List<Program>> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<ProgramService>().fetchPrograms();
  }

  void _openDetails(Program program) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProgramDetailsScreen(programId: program.id)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final service = context.watch<ProgramService>();
    final continuing = service.continueLearning;
    final name = auth.currentUser?.name.split(' ').first ?? 'Learner';

    return FutureBuilder<List<Program>>(
      future: _future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final all = snapshot.data!;
        final recommended = all.where((p) => !p.enrolled).take(4).toList();

        return ListView(
          padding: const EdgeInsets.all(AppConstants.spaceLg),
          children: [
            Text('Hi, $name', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text('Continue where you left off',
                style: TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                hintText: 'Search programs, skills...',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: AppColors.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
              ),
              onSubmitted: (_) {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const ProgramListingScreen()),
                );
              },
            ),
            const SizedBox(height: 20),
            if (continuing.isNotEmpty) ...[
              for (final p in continuing) _ContinueCard(program: p, onTap: () => _openDetails(p)),
              const SizedBox(height: 8),
            ],
            const Text('Browse Categories',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            const SizedBox(height: 10),
            SizedBox(
              height: 72,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: AppConstants.categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (context, i) {
                  final category = AppConstants.categories[i];
                  return _CategoryChip(
                    label: category,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ProgramListingScreen(initialCategory: category),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 24),
            const Text('Recommended for you',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            const SizedBox(height: 10),
            for (final program in recommended)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ProgramCard(program: program, onTap: () => _openDetails(program)),
              ),
          ],
        );
      },
    );
  }
}

class _ContinueCard extends StatelessWidget {
  final Program program;
  final VoidCallback onTap;
  const _ContinueCard({required this.program, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(program.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 4),
              Text('Module ${(program.progress * 10).clamp(1, 10).round()} of 10',
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5)),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: program.progress,
                  minHeight: 8,
                  backgroundColor: AppColors.border,
                  valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                ),
              ),
              const SizedBox(height: 6),
              Text('${(program.progress * 100).round()}% complete',
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _CategoryChip({required this.label, required this.onTap});

  static const icons = {
    'Dev': Icons.code_rounded,
    'Data': Icons.bar_chart_rounded,
    'Design': Icons.palette_rounded,
    'Cloud': Icons.cloud_rounded,
  };

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 84,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icons[label] ?? Icons.category_rounded, color: AppColors.primary, size: 20),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
