import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/program_model.dart';
import '../services/program_service.dart';
import '../utils/constants.dart';
import '../utils/theme.dart';
import '../widgets/custom_button.dart';
import 'feedback_screen.dart';

class ProgramDetailsScreen extends StatefulWidget {
  final String programId;
  const ProgramDetailsScreen({super.key, required this.programId});

  @override
  State<ProgramDetailsScreen> createState() => _ProgramDetailsScreenState();
}

class _ProgramDetailsScreenState extends State<ProgramDetailsScreen> {
  bool _isEnrolling = false;

  Future<void> _enroll(Program program) async {
    setState(() => _isEnrolling = true);
    await context.read<ProgramService>().enroll(program.id);
    if (!mounted) return;
    setState(() => _isEnrolling = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Enrolled in "${program.title}"! It now appears in your progress tracker.'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final service = context.watch<ProgramService>();
    final program = service.getById(widget.programId);

    return Scaffold(
      appBar: AppBar(title: const Text('Program Details')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
            AppConstants.spaceLg, AppConstants.spaceMd, AppConstants.spaceLg, 100),
        children: [
          Container(
            height: 160,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(16),
            ),
            alignment: Alignment.center,
            child: const Icon(Icons.menu_book_rounded, size: 48, color: AppColors.primary),
          ),
          const SizedBox(height: 16),
          Text(program.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Row(
            children: [
              Text('By ${program.instructor}',
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
              const SizedBox(width: 8),
              const Icon(Icons.star_rounded, size: 16, color: Color(0xFFF59E0B)),
              Text(' ${program.rating}', style: const TextStyle(fontSize: 13)),
            ],
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            children: [
              _MetaChip(label: program.duration),
              _MetaChip(label: program.level),
              const _MetaChip(label: 'Certificate'),
            ],
          ),
          const SizedBox(height: 18),
          const Text('About this program',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 8),
          Text(program.description,
              style: const TextStyle(color: AppColors.textSecondary, height: 1.5)),
          const SizedBox(height: 20),
          const Text('Curriculum', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 8),
          ...List.generate(program.curriculum.length, (i) {
            final module = program.curriculum[i];
            return Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ExpansionTile(
                  title: Text('Module ${i + 1}: ${module.title}',
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                  subtitle: Text(module.duration,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Covers key concepts of "${module.title}" with guided exercises '
                          'and a short knowledge check.',
                          style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
          if (program.enrolled) ...[
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => FeedbackScreen(programTitle: program.title),
                ),
              ),
              icon: const Icon(Icons.rate_review_outlined),
              label: const Text('Leave feedback for this program'),
            ),
          ],
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppConstants.spaceLg),
          child: CustomButton(
            label: program.enrolled ? 'Enrolled ✓' : 'Enroll Now',
            isLoading: _isEnrolling,
            onPressed: program.enrolled ? null : () => _enroll(program),
          ),
        ),
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final String label;
  const _MetaChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      backgroundColor: AppColors.background,
      side: const BorderSide(color: AppColors.border),
      visualDensity: VisualDensity.compact,
    );
  }
}
